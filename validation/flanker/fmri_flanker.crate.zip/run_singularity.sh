#!/usr/bin/env bash
set -euo pipefail

# If --help is passed, show usage
if [ "${1:-}" = "--help" ] || [ "${1:-}" = "-h" ]; then
  echo "=== niBuild Workflow Runner (Singularity) ==="
  echo ""
  echo "Usage:"
  echo "  Direct:    ./run_singularity.sh"
  echo "  Container: singularity run my-pipeline.sif"
  echo ""
  echo "File inputs (edit job.yml before running):"
  echo "  t1w  (File[])"
  echo "  bold  (File[])"
  echo "  mcflirt_ref_file  (File)"
  echo "  mcflirt_init  (File)"
  echo "  fnirt_reference  (File)"
  echo "  fnirt_affine  (File)"
  echo "  fnirt_inwarp  (File)"
  echo "  fnirt_intin  (File)"
  echo "  fnirt_config  (File)"
  echo "  fnirt_refmask  (File)"
  echo "  fnirt_inmask  (File)"
  echo "  flirt_init_matrix  (File)"
  echo "  flirt_in_weight  (File)"
  echo "  flirt_ref_weight  (File)"
  echo "  flirt_wm_seg  (File)"
  echo "  flirt_fieldmap  (File)"
  echo "  flirt_fieldmapmask  (File)"
  echo "  flirt_schedule  (File)"
  echo "  applywarp_reference  (File)"
  echo "  applywarp_postmat  (File)"
  echo "  applywarp_mask  (File)"
  echo "  film_gls_design_file  (File[])"
  echo "  film_gls_contrast_file  (File)"
  echo "  flameo_mask_file  (File)"
  echo "  flameo_design_file  (File)"
  echo "  flameo_t_con_file  (File)"
  echo "  flameo_cov_split_file  (File)"
  echo "  flameo_f_con_file  (File)"
  echo "  flameo_dof_var_cope_file  (File)"
  echo ""
  echo "All scalar parameters are pre-configured in job.yml."
  echo "Edit job.yml to set file paths before running."
  echo ""
  echo "Extra arguments are passed to cwltool (e.g. --verbose, --cachedir /cache)."
  exit 0
fi

cwltool --singularity --outdir /output "$@" \
  workflows/fmri_flanker.cwl \
  job.yml
