#!/usr/bin/env bash
set -euo pipefail

# If --help is passed, show usage
if [ "${1:-}" = "--help" ] || [ "${1:-}" = "-h" ]; then
  echo "=== niBuild Workflow Runner ==="
  echo ""
  echo "Usage: docker run -v /path/to/data:/data -v /path/to/output:/output <image>"
  echo ""
  echo "File inputs (edit job.yml before running):"
  echo "  t1w  (File[])"
  echo "  bold  (File[])"
  echo "  mcflirt_ref_file  (File)"
  echo "  mcflirt_init  (File)"
  echo "  fnirt_reference  (File)"
  echo "  fnirt_affine  (File)"
  echo "  fnirt_inwarp  (File)"
  echo "  fnirt_intin  (File)"
  echo "  fnirt_config  (File)"
  echo "  fnirt_refmask  (File)"
  echo "  fnirt_inmask  (File)"
  echo "  flirt_init_matrix  (File)"
  echo "  flirt_in_weight  (File)"
  echo "  flirt_ref_weight  (File)"
  echo "  flirt_wm_seg  (File)"
  echo "  flirt_fieldmap  (File)"
  echo "  flirt_fieldmapmask  (File)"
  echo "  flirt_schedule  (File)"
  echo "  applywarp_reference  (File)"
  echo "  applywarp_postmat  (File)"
  echo "  applywarp_mask  (File)"
  echo "  film_gls_design_file  (File[])"
  echo "  film_gls_contrast_file  (File)"
  echo "  flameo_mask_file  (File)"
  echo "  flameo_design_file  (File)"
  echo "  flameo_t_con_file  (File)"
  echo "  flameo_cov_split_file  (File)"
  echo "  flameo_f_con_file  (File)"
  echo "  flameo_dof_var_cope_file  (File)"
  echo ""
  echo "All scalar parameters are pre-configured in job.yml."
  echo "Edit job.yml to set file paths before running."
  echo ""
  echo "BIDS mode: ./run.sh --bids /absolute/path/to/bids/dataset"
  echo "  (the BIDS path must be absolute)"
  echo ""
  echo "Extra arguments are passed to cwltool (e.g. --verbose, --cachedir /cache)."
  exit 0
fi

# BIDS mode: resolve dataset paths automatically
if [ "${1:-}" = "--bids" ]; then
  BIDS_DIR="${2:-}"
  if [ -z "${BIDS_DIR:-}" ]; then
    echo "Error: --bids requires a path to a BIDS dataset directory"
    exit 1
  fi
  shift 2
  echo "Resolving BIDS inputs from: $BIDS_DIR"
  python3 resolve_bids.py \
    --bids-dir "$BIDS_DIR" \
    --query bids_query.json \
    --job job.yml \
    --output job.yml \
    --relative-to .
  cwltool --outdir /output "$@" \
    workflows/fmri_flanker.cwl \
    job.yml
  exit 0
fi

cwltool --outdir /output "$@" \
  workflows/fmri_flanker.cwl \
  job.yml
